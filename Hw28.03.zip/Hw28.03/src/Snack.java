public enum Snack {
    CHIPS,
    NUGGETS,
    SALADS,
    POPCORN
}
