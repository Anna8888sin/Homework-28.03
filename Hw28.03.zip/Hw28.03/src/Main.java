import java.util.Scanner;

public class Main {
    /*
       1 уровень сложности: Проект 1. Перечисления
Создайте перечисление для угощений в снек-автомате (3-4 позиции).
Пользователь вводит номер снека. Программа должна вывести название снека,
 который выдал автомат.*/
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Введите номер снека: ");
        int snackNumber = scn.nextInt();
        if (snackNumber == 1) {
            System.out.println(Snack.CHIPS);
        }
        if (snackNumber == 2) {
            System.out.println(Snack.NUGGETS);
        }
        if (snackNumber == 3) {
            System.out.println(Snack.SALADS);
        }
        if (snackNumber == 4) {
            System.out.println(Snack.POPCORN);
        }
    }
}