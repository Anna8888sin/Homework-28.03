public class Student {
/*
  2 Создайте геттеры и сеттеры для этих полей.
3 Создайте конструктор, который принимает значения для инициализации поля name.
4 Создайте конструктор, который принимает значения для инициализации обоих полей.
Инициализацию имени конструктор должен делегировать в конструктор из пункта 3, а
затем инициализировать оставшееся поле group.
5 Создайте клонирующий конструктор, который принимает объект типа Student и создаёт
нового студента на его основе.
6 В основной программе создайте переменную student1, проинициализируйте её с помощью
оператора new и с помощью конструктора.
7 В переменную student2 присвойте значение student1.
8 В переменную student3 присвойте значение, полученное с помощью клонирующего конструктора.
9 Измените значение поля name у student1.
10 Выведите на консоль значения полей student1, student2 и student3.*/
        private String name;

        private int group;

        public Student (String name){
            this.name = name;
        }
        public Student (String name, int group){
            this(name);
            this.group = group;
        }
        public Student (Student it) {
            this.name = it.name;
            this.group = it.group;
        }

        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
        public int getGroup() {
            return group;
        }
        public void setGroup(int group) {
            this.group = group;
        }
    }

