public class Main {
    /*
      Проект 2. Создание конструкторов и методов доступа
1 Создайте класс Student, содержащий поля name и group. Поля сделайте приватными.
*/
    public static void main(String[] args) {
        Student student1 = new Student("Иван", 290379);
        Student student3 = new Student(student1);
        student1.setName("Наум");

        System.out.println(student1.getName() + " " + student1.getGroup());
        System.out.println(student1.getName() + " " + student1.getGroup());
        System.out.println(student3.getName() + " " + student3.getGroup());



    }
}